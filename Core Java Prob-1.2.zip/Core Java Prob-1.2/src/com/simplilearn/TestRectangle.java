package com.simplilearn;

public class TestRectangle {

	public static void main(String[] args) {
		
		//creating a rectangle object
		
		Rectangle rect1=new Rectangle(4,4);
		Rectangle rect2=new Rectangle(7,7);
		Rectangle rect3=new Rectangle(5,5);
		Rectangle rect4=new Rectangle(6,6);
		Rectangle rect5=new Rectangle(3,3);
		
		
		
		//print rect1
		rect1.printRectangle();
		
		//print rect2
		rect2.printRectangle();
		
		//print rect3
		rect3.printRectangle();
		
		//print rect4
		rect4.printRectangle();
		
		//print rect5
		rect5.printRectangle();
		
		

	}

}
