package com.simplilearn;

public class Rectangle {	
		
		private int length;
		private int breadth;
		private int area;
		
		
		public Rectangle(int lt, int bt) { //user values
			length=lt;
			breadth=bt;
			setarea();
		}
		
		public void setlength(int lt) {
			length= lt;
		}
		public int getlength() {
			return length;
		}
		
		public void setbreadth(int bt) {
			breadth= bt;
		}
		public int getbreadth() {
			return breadth;
		}
		public int getarea() {
			return area;
		}
		public void setarea() {
			area=length*breadth;
		}
		
		//method to print area
		public void printRectangle() {
			
			System.out.println("Length:" + getlength());
			System.out.println("Breadth:" + getbreadth());
			System.out.println("Area:" + getarea());
		}
		
		

	}


