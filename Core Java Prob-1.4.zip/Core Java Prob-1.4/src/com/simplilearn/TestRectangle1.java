package com.simplilearn;

public class TestRectangle1 {

	public static void main(String[] args) {
		
		//creating object
		Rectangle r1=new Rectangle();
		Rectangle r2=new Rectangle();
		
		r1.setLength(5);
		r1.setBreadth(5);
		r1.setArea();
		r1.setPerimeter();
		
		r2.setLength(3);
		r2.setBreadth(3);
		r2.setArea();
		r2.setPerimeter();
		
		//printing r1,r2 area,perimeter
		r1.printRectangle();
		r2.printRectangle();	

	}

}
