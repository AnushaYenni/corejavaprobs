package com.simplilearn;

public class Rectangle {
	
	private float Length;
	private float Breadth;
	private float Area;
	private float Perimeter;
	
	
	//Default value which is equal to 1
	public Rectangle() {
		 Length=1;
		 Breadth=1;
		 setArea();
		 setPerimeter();	 
	}
	
	
	//getters and setters
	public float getLength() {
		return Length;
	}
	public void setLength(float Length) {
		this.Length = Length;
	}
	public float getBreadth() {
		return Breadth;
	}
	public void setBreadth(float breadth) {
		Breadth = breadth;
	}
	
	public float getArea() {
		return Area;
	}
	public void setArea() {
		Area = Length*Breadth;
	}
	public float getPerimeter() {
		return Perimeter;
	}
	public void setPerimeter() {
		Perimeter = 2*(Length+Breadth);
	}
	
	//print area and perimeter
	public void printRectangle() {
		
		System.out.println("Length:" + getLength());
		System.out.println("Breadth:" + getBreadth());
		System.out.println("Area:" + getArea());
		System.out.println("Perimeter:" + getPerimeter());
	}
	
	
	

}
